﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

namespace ConsoleApp1

{

    class Program

    {


        static void Main(string[] args)

        {
            
          // PGPEncryptDecrypt.EncryptFile(@"C:\Users\psp10\source\repos\ConsoleApp1\ConsoleApp1\files\originalfile.txt", @"C:\Users\psp10\source\repos\ConsoleApp1\ConsoleApp1\files\encrypted.pgp", @"C:\Users\psp10\source\repos\ConsoleApp1\ConsoleApp1\keys\0x004D1DB5-pub.asc", false, true);
            PGPEncryptDecrypt.Decrypt(@"C:\Users\psp10\source\repos\ConsoleApp1\ConsoleApp1\files\encrypted.pgp", @"C:\Users\psp10\source\repos\ConsoleApp1\ConsoleApp1\keys\0x004D1DB5-sec.asc", @"pradeep", @"C:\Users\psp10\source\repos\ConsoleApp1\ConsoleApp1\files\decrypted.txt");
            //PGPEncryptDecrypt.Decrypt(@"D:\PGPProject\TESTDATAEncrypt.pgp", @"D:\PGPProject\PrivateKey\TESTGPG_0xCBEDD228_SECRET.asc", “Test@1234", @"D:\PGPProject\TESTDATA_Out.txt");

        }

    }

}